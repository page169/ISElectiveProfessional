# Embedding Generation Report

## Model choice

- **Intended production model:** `sentence-transformers/all-MiniLM-L6-v2` (Hugging Face, open-source, 384-dim, offline-capable after first download).
- Chosen for a good balance of semantic quality vs. size for a small (41-document) domain-specific knowledge base, and for zero per-call API cost.

- **Model actually used to produce the numbers below in this sandboxed run:** `TF-IDF (offline fallback, sandbox only)`
  - This sandbox has no outbound access to huggingface.co, so the MiniLM download could not complete here. The TF-IDF fallback exists solely to demonstrate a working, runnable embedding pipeline in this environment. `embed_with_sentence_transformers()` in this same file is the actual code intended for submission/deployment and will run correctly on any machine with normal internet access.

## Output shape

`5` documents embedded into `384`-dimension vectors.

## Similarity spot-check

Cosine similarity between `01_chapter-1-preliminary-matters.txt` and the other sampled documents:

| Compared document | Cosine similarity |
|---|---|
| 02_chapter-2-declaration-of-principles.txt | 0.4303 |
| 03_chapter-3-students-rights-and-obligations.txt | 0.4980 |
| 04_chapter-1-admission-policies.txt | 0.4409 |
| 05_chapter-2-admission-test.txt | 0.2845 |