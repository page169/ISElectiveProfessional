# Preprocessing Before/After Report

Checkpoint 1 evidence: text cleaning, normalization, and tokenization
applied to the TPC Student Handbook raw dataset (41 documents, extracted
from the instructor-provided handbook PDF).

## Sample before/after (first 3 documents)

### 01_chapter-1-preliminary-matters.txt

**Raw (1850 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 1: Preliminary Matters\n\nChapter 1\n              PRELIMINARY MATTERS\nSection 1. This document shall be called and known as the\n“Tal...
```

**Cleaned (1698 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 1: Preliminary Matters\n\nChapter 1\n PRELIMINARY MATTERS\nSection 1. This document shall be called and known as the\n“Talibon Polytech...
```

Tokens produced: 251

### 02_chapter-2-declaration-of-principles.txt

**Raw (1082 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 2: Declaration of Principles\n\nChapter 2\n          DECLARATION OF PRINCIPLES\nSection 1. TPC recognizes the vital role of the youth ...
```

**Cleaned (1072 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 2: Declaration of Principles\n\nChapter 2\n DECLARATION OF PRINCIPLES\nSection 1. TPC recognizes the vital role of the youth in\nnation...
```

Tokens produced: 156

### 03_chapter-3-students-rights-and-obligations.txt

**Raw (6413 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 3: Students' Rights and Obligations\n\nChapter 3\n   STUDENTS’ RIGHTS AND OBLIGATIONS\nSection 1. Rights – The following rights under ...
```

**Cleaned (5743 chars):**
```
TPC STUDENT HANDBOOK\nSection: Article I - Chapter 3: Students' Rights and Obligations\n\nChapter 3\n STUDENTS’ RIGHTS AND OBLIGATIONS\nSection 1. Rights – The following rights under th...
```

Tokens produced: 891

## Summary across all documents

| File | Raw chars | Clean chars | Tokens |
|---|---|---|---|
| 01_chapter-1-preliminary-matters.txt | 1850 | 1698 | 251 |
| 02_chapter-2-declaration-of-principles.txt | 1082 | 1072 | 156 |
| 03_chapter-3-students-rights-and-obligations.txt | 6413 | 5743 | 891 |
| 04_chapter-1-admission-policies.txt | 536 | 521 | 80 |
| 05_chapter-2-admission-test.txt | 720 | 702 | 97 |
| 06_chapter-3-admission-requirements.txt | 3774 | 3476 | 537 |
| 07_chapter-4-registration-enrolment-policies.txt | 1070 | 1067 | 164 |
| 08_chapter-5-academic-information.txt | 20472 | 19922 | 3259 |
| 09_chapter-6-grading-system.txt | 1038 | 507 | 121 |
| 10_chapter-7-graduation.txt | 4809 | 4257 | 646 |
| 11_chapter-8-transfer-credentials.txt | 885 | 827 | 126 |
| 12_chapter-9-retention-policies.txt | 1422 | 1406 | 249 |
| 13_chapter-10-admission-enrolment-process.txt | 2302 | 1815 | 295 |
| 14_chapter-11-college-admission-and-enrollment-policy.txt | 7135 | 6626 | 963 |
| 15_chapter-1-library-services.txt | 4610 | 4568 | 714 |
| 16_chapter-2-health-services.txt | 3489 | 3405 | 517 |
| 17_chapter-3-guidance-and-counseling.txt | 4791 | 4781 | 713 |
| 18_chapter-4-canteen-food-services.txt | 865 | 853 | 135 |
| 19_chapter-5-scholarship-unit.txt | 2162 | 1985 | 287 |
| 20_chapter-6-safety-and-security.txt | 6254 | 5646 | 877 |
| 21_chapter-7-sports-and-athletics.txt | 2382 | 2202 | 288 |
| 22_chapter-8-arts-and-cultural.txt | 4347 | 3981 | 564 |
| 23_chapter-9-student-affairs-and-services.txt | 37353 | 33813 | 5100 |
| 24_chapter-1-preliminary.txt | 3903 | 3700 | 582 |
| 25_chapter-2-norms-of-conduct.txt | 2281 | 1906 | 305 |
| 26_chapter-3-non-academic-policy.txt | 6054 | 5855 | 959 |
| 27_chapter-4-grounds-of-disciplinary-actions-and-sanc.txt | 14904 | 11919 | 1828 |
| 28_administrative-due-process.txt | 25060 | 20501 | 3249 |
| 29_the-office-of-treasurer.txt | 356 | 342 | 55 |
| 30_the-office-of-the-college-registrar.txt | 663 | 649 | 89 |
| 31_education-tour-field-policies-and-guideline.txt | 7047 | 6632 | 1046 |
| 32_on-the-job-training-practicum-internship-policies-.txt | 4973 | 4568 | 709 |
| 33_transitory-provisions.txt | 1095 | 1081 | 164 |
| 34_data-privacy-consent-form.txt | 10381 | 9756 | 1425 |
| 35_student-related-law-and-memoranda.txt | 2052 | 1943 | 299 |
| 36_courses-and-programs-offered.txt | 432 | 429 | 63 |
| 37_purpose.txt | 1340 | 1318 | 199 |
| 38_definition-of-terms.txt | 3736 | 3354 | 504 |
| 39_objectives.txt | 1368 | 1256 | 191 |
| 40_general-rules.txt | 4388 | 4336 | 684 |
| 41_requirements.txt | 11548 | 7212 | 1035 |

**Totals:** 41 documents, 221342 raw chars -> 197630 clean chars (23712 chars removed by cleaning), 30416 tokens generated.